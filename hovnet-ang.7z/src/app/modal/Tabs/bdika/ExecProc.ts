export class ExecProc {
   CaseDisplayIdentifier:string;
   SourceCaseSequenceNum:string;
   ProcessNumber:string;
   OrdinalNumber:number;
   ExecutionProceedingTypeID:number;
   ExecutionDate:Date;
   ExecutionActionStateID:number;
   ImportDate:Date;
   InitiationDate:Date;
   // return  " CaseDisplayIdentifier, SourceCaseSequenceNum, ProcessNumber, OrdinalNumber, ExecutionProceedingTypeID, InitiationDate, ExecutionActionStateID, ExecutionDate, ImportDate FROM dbo.NetHoz_ExecutionProceeding"

  }
 