import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mis1',
  templateUrl: './mis1.component.html',
  styleUrls: ['./mis1.component.css']
})
export class Mis1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
