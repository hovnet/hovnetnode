export class GlobalConstants {
   public static GBL: any
   public static apiURL: string = "https://itsolutionstuff.com/";
     
   public static siteTitle: string = "This is example of ItSolutionStuff.com";

}