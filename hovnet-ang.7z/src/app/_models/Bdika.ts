export class Bdika {
  hotzlap:string;
  MisparPnimi:string;
  HayavNum:number;
  shemHayav:string;
  TikStatus:string;
  SideStatus:string;
  Lbakasha:string;
  ShemLakoach:string;
  yitraHotzlap:number;
  IsIkuv:string;
  MoneTik:number;
  MoneSide:number;
 }
