export class User {
   Counter: number;
   id: number;
   username: string;
   password: string;
   firstName: string;
   lastName: string;
   tsCreatedDate: Date;
   tsCreatedBy: string;
   tsUpdateDate: Date;
   tsUpdateBy: string;
   Comment: string;
   OldPassword: string;
   privil: string;
   ClientCounter: number;
   Email: string;
   Phone: string;
   misrad: number;
   authdata?: string;
   ip:string;
   Code:string;
   Name:string;
   Suspend:boolean;
   Status:string;
}

