import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-next-panel',
  templateUrl: './next-panel.component.html',
  styleUrls: ['./next-panel.component.css']
})
export class NextPanelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
