import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-template-e',
  templateUrl: './template-e.component.html',
  styleUrls: ['./template-e.component.css']
})
export class TemplateEComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
