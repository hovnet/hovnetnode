export const environment = {
  production: true,
  apiUrl: 'http://hovnet.co.il/api',
  apiUrlDocs: 'http://hovnet.co.il/apd'
  // apiUrl: 'http://185.240.142.43/api',
  // apiUrlDocs: 'http://185.240.142.43l/apd'
};

