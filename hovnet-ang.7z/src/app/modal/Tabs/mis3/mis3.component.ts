import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mis3',
  templateUrl: './mis3.component.html',
  styleUrls: ['./mis3.component.css']
})
export class Mis3Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
