import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mis2',
  templateUrl: './mis2.component.html',
  styleUrls: ['./mis2.component.css']
})
export class Mis2Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
